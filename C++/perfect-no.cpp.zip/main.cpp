#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int t;
    cin>>t;
    while(t!=0)
    {
    
      int n,i=1,s=0;
      cin>>n;
      while(i<n)
      {
        if(n%i==0)
        s=s+i;
        i++;
      }
      if(s==n)
      cout<<"true"<<endl;
      else
      cout<<"false"<<endl; 
      t--;
    }
    return 0;
  }
