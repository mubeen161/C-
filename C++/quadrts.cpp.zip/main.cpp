/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<cmath> 
using namespace std;
int main()
{
    float a,b,c,rt1,rt2;
    cout<<"Enter the values of a ,b,c ";
    cin>>a>> b>> c;
    rt1=(-b+sqrt(b*b-4*a*c))/(2*a);
    rt2=(-b-sqrt(b*b-4*a*c))/(2*a);
    cout<<"Roots of quadratic equation are "<<rt1<<"  "<<rt2;
    return 0; 
} 
    
