#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int i,j,n,t;
    cin>>n;
    t=n;
    for(i=5;i>=1;i--)
    {
      for(j=i;j>=1;j--)
      {
        cout<<t<<" ";
        t++;
      }
      t=n;
      cout<<endl;
    } 
  
    
    return 0;
  }