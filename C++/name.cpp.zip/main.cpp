#include<iostream>
using namespace std;
int main()
{
    string str;
    cout<<"enter the name ";
    getline(cin,str);
    cout<<"hello mr or miss "<<str;
    return 0;
}


