/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int x,y,z;
    cout<<"Enter the 3 numbers : ";
    cin>>x>>y>>z;
    if(x<y&&x>z||x>y&&x<y)
    cout<<"The second smallest number is "<<x;
    else if(y<x&&y>z||y>x&&y<x)
    cout<<"The second smallest number is "<<y;
    else
    cout<<"The second smallest number is "<<z;
    
    
    return 0;
  }