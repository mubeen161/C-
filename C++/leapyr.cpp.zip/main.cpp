/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int yr;
    cout<<"Enter the year of Birth : ";
    cin>>yr;
    if(yr%4==0)
    cout<<yr<<" is a Leap year ";
    else
    cout<<yr<<" is not a Leap year";
    
    return 0;
  }