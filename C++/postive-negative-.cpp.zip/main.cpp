/*program to find positive and negative number*/
#include<iostream>
using namespace std;
int
main ()
{
  int x;
  cout << "Enter the number : ";
  cin >> x;
  if (x >= 0)
    {
      cout << "%d is a postive number " << x;
    }
  else
    {
      cout << "%d is a negative number" << y;
    }
    return 0; 
}
