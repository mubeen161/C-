/*Program to find odd and even*/
#include<iostream>
int main()
{
    int x;
    cout<<"Enter number ";
    cin>>x;
    if(x%==0)
    {
        cout<<" %d is even"<<x;
    }
    else
    {
        cout<<"%d is odd"<<x;
    }
    return 0;
}

