/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int x,y;
    cout<<"Enter the 2 values : ";
    cin>>x>>y;
    if(x==y)
    cout<<"The value of "<<x<<" and "<<y <<"are equal";
    else if(x>y)
    cout<<"The value of "<<x<<" is greater than "<<y;
    else
    cout<<"The value of "<<x<<" is less than "<<y;
    
    return 0;
  }
