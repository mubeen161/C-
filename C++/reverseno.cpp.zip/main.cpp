#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin 
    int x,t;
    cin>>x; 
    while(x!=0)
    {
      t=x%10;
      x=x/10;
      cout<<t; 
    }
    
    return 0;
  } 