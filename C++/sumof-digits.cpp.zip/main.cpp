#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int x,i,n,sum=0;
    cin>>x;
    while(x!=0)
    {
      n=x%10;
      sum=sum+n;
      x=x/10;
    }
    cout<<sum; 
      
  
  
    return 0;
  }