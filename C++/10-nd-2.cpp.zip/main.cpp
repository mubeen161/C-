//geting 0 as remainder if divided by 10
#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int t;
    cin>>t;
    while(t!=0)
    {
      int n,i,count=0;
      cin>>n;
      if(n%10==0)
      cout<<"number of operations performed is 0";
      else
      {
        while(n%10!=0)
        {
          n=n*2;
          count++;
        }
      cout<<"number of operations performed is "<<count<<endl;
      }
      t--;
    }

    
    return 0;
  }