#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    int i,j,n;
    cin>>n;
    for(i=1;i<=5;i++)
    {
      for(j=1;j<=i;j++)
      {
        cout<<n<<" ";
      }
      cout<<endl;
    }
  
    
    return 0;
  }