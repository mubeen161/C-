#include <bits/stdc++.h>
  using namespace std;
  
  int main()
  {
    //done by mohammed mubeen uddin
    char ch='v';
    int i,j,k;
    for(i=i;i<=5;i++)
    {
      for(j=1;j<=i;j++)
      {
        cout<<j;
      }
      for(j=2*i;j<10;j++)
      {
        cout<< " ";
      } 
      for(k=i;k>=1;k--)
      {
        cout<<k;
      }
      cout<<endl;
    } 
  
    
    return 0;
  }