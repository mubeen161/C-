#include<iostream>

using namespace std;
int main()
{
    int v,u,a;
    float s;
    cout<<"Enter the values of u,v,a: ";
    cin>>u>>v>>a;
    s=(v*v-u*u)/(2*a);
    cout<<"The speed is : "<<s;
    return 0;
}

    